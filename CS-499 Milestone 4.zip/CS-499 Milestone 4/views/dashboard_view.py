import pandas as pd
import plotly.express as px
import dash_leaflet as dl
from dash import dcc, html
from dash.dependencies import Input, Output


def register_callbacks(app, df, model):

    # -------------------------------------------------
    # SEARCH DATABASE USING TEXT INDEX
    # -------------------------------------------------
    @app.callback(
        Output('datatable-id', 'data'),
        Input('search-box', 'value')
    )
    def search_database(query):

        # If nothing typed, show full dataset
        if not query:
            return df.to_dict('records')

        # Use MongoModel search
        results = model.search_text(query)

        # Remove Mongo _id before displaying
        if '_id' in results.columns:
            results.drop(columns=['_id'], inplace=True)

        return results.to_dict('records')

    # -------------------------------------------------
    # PIE CHART — TOP COLORS
    # -------------------------------------------------
    @app.callback(
        Output('graph-id', "children"),
        Input('datatable-id', "derived_virtual_data")
    )
    def update_pie(viewData):

        if viewData is None or len(viewData) == 0:
            return dcc.Graph(figure=px.pie(title='No data'))

        dff = pd.DataFrame(viewData)

        if 'color' not in dff.columns:
            return dcc.Graph(figure=px.pie(title='No color data'))

        top_colors = dff['color'].value_counts().nlargest(10).index
        top_df = dff[dff['color'].isin(top_colors)]

        fig = px.pie(top_df, names='color', title='Top Animal Colors')

        return dcc.Graph(figure=fig)

    # -------------------------------------------------
    # MAP UPDATE
    # Shows selected animal location
    # -------------------------------------------------
    @app.callback(
        Output('map-id', "children"),
        [Input('datatable-id', "derived_virtual_data"),
         Input('datatable-id', "derived_virtual_selected_rows")]
    )
    def update_map(viewData, selected_rows):

        # Default map center (US center)
        default_lat = 39.8283
        default_long = -98.5795

        if viewData is None or len(viewData) == 0:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        dff = pd.DataFrame(viewData)

        # If nothing selected just show default map
        if not selected_rows:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        row = selected_rows[0]

        # Make sure selected index exists
        if row >= len(dff):
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        # Verify coordinates exist
        if 'latitude' not in dff.columns or 'longitude' not in dff.columns:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        # Build map centered on selected animal
        return dl.Map(
            style={'width': '100%', 'height': '500px'},
            center=[dff.iloc[row]['latitude'], dff.iloc[row]['longitude']],
            zoom=10,
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[dff.iloc[row]['latitude'],
                              dff.iloc[row]['longitude']],
                    children=[
                        dl.Tooltip(dff.iloc[row]['breed']),
                        dl.Popup([
                            html.H1("Animal Name"),
                            html.P(dff.iloc[row]['name'])
                        ])
                    ]
                )
            ]
        )
