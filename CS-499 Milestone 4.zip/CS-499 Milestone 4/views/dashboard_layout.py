import base64
from dash import dcc, html, dash_table


def build_layout(df, logo_path="assets/Grazioso Salvare Logo.png"):

    # Convert logo to base64 so Dash can display it
    encoded_image = base64.b64encode(open(logo_path, 'rb').read())

    return html.Div([

        # ---------- HEADER ----------
        html.Div(
            style={'display': 'flex','alignItems':'center','justifyContent':'center'},
            children=[
                html.Img(
                    src='data:image/png;base64,{}'.format(encoded_image.decode()),
                    style={'height':'100px','marginRight':'20px'}
                ),
                html.Center(html.B(html.H1('CS-340 Dashboard Ayers')))
            ]
        ),

        html.Hr(),

        # ---------- SEARCH INPUT ----------
        # Lets user search MongoDB text index
        html.Div([
            html.H3("Database Search"),
            dcc.Input(
                id="search-box",
                type="text",
                placeholder="Search name, breed, or color",
                style={"width":"50%"}
            )
        ]),

        html.Hr(),

        # ---------- MAIN DATA TABLE ----------
        dash_table.DataTable(
            id='datatable-id',
            columns=[{"name": i, "id": i} for i in df.columns],
            data=df.to_dict('records'),

            # Built-in Dash features
            filter_action="native",
            sort_action="native",
            row_selectable="single",
            page_size=10
        ),

        html.Hr(),

        # ---------- GRAPH + MAP ----------
        html.Div(
            style={'display':'flex','height':'520px'},
            children=[
                html.Div(id='graph-id', style={'width':'50%'}),
                html.Div(id='map-id', style={'width':'50%'})
            ]
        )
    ])
