from dash import Dash
from models.mongo_model import MongoModel
from views.dashboard_layout import build_layout
from views.dashboard_view import register_callbacks

# Update your MongoDB URI here
MONGO_URI = "mongodb+srv://testuser:Hacksaw91@cluster0.9cvmi1z.mongodb.net/"


app = Dash(__name__)

model = MongoModel(MONGO_URI)
df = model.read_all()

if '_id' in df.columns:
    df.drop(columns=['_id'], inplace=True)

app.layout = build_layout(df)
register_callbacks(app, df)

if __name__ == "__main__":
    app.run(debug=True, port=8050)
