import base64
from dash import dcc, html, dash_table

def build_layout(df, logo_path="assets/Grazioso Salvare Logo.png"):
    encoded_image = base64.b64encode(open(logo_path, 'rb').read())

    return html.Div([
        html.Div(
            style={'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'},
            children=[
                html.Img(
                    src='data:image/png;base64,{}'.format(encoded_image.decode()),
                    style={'height': '100px', 'width': 'auto', 'marginRight': '20px'}
                ),
                html.Center(html.B(html.H1('CS-340 Dashboard Ayers')))
            ]
        ),
        html.Hr(),

        html.Div([
            html.B(html.H2('Rescue Type')),
            dcc.Dropdown(
                id='filter-type',
                options=[
                    {'label': 'Water Rescue', 'value': "Water"},
                    {'label': 'Mountain or Wilderness Rescue', 'value': "Mountain or Wilderness"},
                    {'label': 'Disaster or Individual Tracking Rescue', 'value': "Disaster or Individual Tracking"},
                    {'label': 'None', 'value': 'None'}
                ],
                value='None',
            ),
        ]),

        dash_table.DataTable(
            id='datatable-id',
            columns=[{"name": i, "id": i} for i in df.columns],
            data=df.to_dict('records'),
            filter_action="native",
            sort_action="native",
            sort_mode="multi",
            row_selectable="single",
            page_action="native",
            page_current=0,
            page_size=10
        ),

        html.Hr(),

        html.Div(
            style={'display': 'flex', 'height': '520px'},
            children=[
                html.Div(id='graph-id', style={'width': '50%'}),
                html.Div(id='map-id', style={'width': '50%'})
            ]
        )
    ])
