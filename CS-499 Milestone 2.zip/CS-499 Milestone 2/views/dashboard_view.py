import pandas as pd
import plotly.express as px
import dash_leaflet as dl
from dash import dcc, html
from dash.dependencies import Input, Output


def register_callbacks(app, df):

    @app.callback(Output('datatable-id', 'data'),
                  [Input('filter-type', 'value')])
    def update_dashboard(filter_type):
        rescue_map = {
            "Water": {
                "breed": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"],
                "sex_upon_outcome": "Intact Female",
                "age_upon_outcome_in_weeks": (26, 156)
            },
            "Mountain or Wilderness": {
                "breed": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"],
                "sex_upon_outcome": "Intact Male",
                "age_upon_outcome_in_weeks": (26, 156)
            },
            "Disaster or Individual Tracking": {
                "breed": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"],
                "sex_upon_outcome": "Intact Male",
                "age_upon_outcome_in_weeks": (20, 300)
            },
        }

        filtered_df = df.copy()

        if filter_type in rescue_map:
            rules = rescue_map[filter_type]

            if 'breed' in rules:
                filtered_df = filtered_df[filtered_df['breed'].isin(rules['breed'])]

            if 'sex_upon_outcome' in rules:
                filtered_df = filtered_df[filtered_df['sex_upon_outcome'] == rules['sex_upon_outcome']]

            if 'age_upon_outcome_in_weeks' in rules:
                age_min, age_max = rules['age_upon_outcome_in_weeks']
                filtered_df = filtered_df[(filtered_df['age_upon_outcome_in_weeks'] >= age_min) &
                                          (filtered_df['age_upon_outcome_in_weeks'] <= age_max)]

        if filter_type == 'None':
            filtered_df = df.copy()

        return filtered_df.to_dict('records')

    @app.callback(Output('graph-id', "children"),
                  [Input('datatable-id', "derived_virtual_data")])
    def update_pie(viewData):
        if viewData is None or len(viewData) == 0:
            return dcc.Graph(figure=px.pie(title='No data selected'))

        dff = pd.DataFrame(viewData)

        if 'color' not in dff.columns:
            return dcc.Graph(figure=px.pie(title='No "color" data available'))

        top_colors = dff['color'].value_counts().nlargest(10).index
        top_df = dff[dff['color'].isin(top_colors)]

        return dcc.Graph(figure=px.pie(top_df, names='color', title='Top Animal Colors'))

    @app.callback(
        Output('map-id', "children"),
        [Input('datatable-id', "derived_virtual_data"),
         Input('datatable-id', "derived_virtual_selected_rows")]
    )
    def update_map(viewData, selected_rows):

        default_lat = 39.8283
        default_long = -98.5795

        if viewData is None or len(viewData) == 0:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        dff = pd.DataFrame(viewData)

        if not selected_rows:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        row = selected_rows[0]

        if row >= len(dff):
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        # FIXED: Use MongoDB fields
        if 'latitude' not in dff.columns or 'longitude' not in dff.columns:
            return dl.Map(
                style={'width': '100%', 'height': '500px'},
                center=[default_lat, default_long],
                zoom=4,
                children=[dl.TileLayer()]
            )

        return dl.Map(
            style={'width': '100%', 'height': '500px'},
            center=[dff.iloc[row]['latitude'], dff.iloc[row]['longitude']],
            zoom=10,
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[dff.iloc[row]['latitude'], dff.iloc[row]['longitude']],
                    children=[
                        dl.Tooltip(dff.iloc[row]['breed']),
                        dl.Popup([
                            html.H1("Animal Name"),
                            html.P(dff.iloc[row]['name'])
                        ])
                    ]
                )
            ]
        )
