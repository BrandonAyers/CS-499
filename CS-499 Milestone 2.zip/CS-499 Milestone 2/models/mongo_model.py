from pymongo import MongoClient
import pandas as pd

class MongoModel:
    """Model layer for MongoDB interaction."""

    def __init__(self, uri, db_name="aac", collection_name="animals"):
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def read_all(self):
        data = list(self.collection.find({}))
        return pd.DataFrame.from_records(data)

    def close(self):
        self.client.close()
