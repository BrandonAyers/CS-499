from pymongo import MongoClient
import pandas as pd


class MongoModel:
    """Model layer for MongoDB interaction."""

    def __init__(self, mongo_uri, db_name="aac", collection_name="animals"):
        if not mongo_uri:
            raise ValueError("MongoDB URI not provided")

        self.client = MongoClient(mongo_uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def read_all(self):
        """Read all records from MongoDB and return as DataFrame."""
        data = list(self.collection.find({}))
        return pd.DataFrame.from_records(data)

    def close(self):
        self.client.close()
