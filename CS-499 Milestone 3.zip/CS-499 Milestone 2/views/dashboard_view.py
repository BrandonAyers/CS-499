import pandas as pd
import plotly.express as px
import dash_leaflet as dl
from dash import dcc, html
from dash.dependencies import Input, Output


def register_callbacks(app, df):

    @app.callback(
        Output("datatable-id", "data"),
        Input("filter-type", "value")
    )
    def update_dashboard(filter_type):
        rescue_map = {
            "Water": {
                "breed": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"],
                "sex_upon_outcome": "Intact Female",
                "age_range": (26, 156)
            },
            "Mountain or Wilderness": {
                "breed": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"],
                "sex_upon_outcome": "Intact Male",
                "age_range": (26, 156)
            },
            "Disaster or Individual Tracking": {
                "breed": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"],
                "sex_upon_outcome": "Intact Male",
                "age_range": (20, 300)
            }
        }

        if filter_type == "None":
            return df.to_dict("records")

        rules = rescue_map.get(filter_type)
        if not rules:
            return df.to_dict("records")

        filtered = df[
            df["breed"].isin(rules["breed"]) &
            (df["sex_upon_outcome"] == rules["sex_upon_outcome"]) &
            (df["age_upon_outcome_in_weeks"].between(*rules["age_range"]))
        ]

        return filtered.to_dict("records")

    @app.callback(
        Output("graph-id", "children"),
        Input("datatable-id", "derived_virtual_data")
    )
    def update_pie(view_data):
        if not view_data:
            return dcc.Graph(figure=px.pie(title="No data available"))

        dff = pd.DataFrame(view_data)

        if "color" not in dff:
            return dcc.Graph(figure=px.pie(title="Color data unavailable"))

        top_colors = dff["color"].value_counts().nlargest(10).index
        filtered = dff[dff["color"].isin(top_colors)]

        return dcc.Graph(
            figure=px.pie(filtered, names="color", title="Top Animal Colors")
        )

    @app.callback(
        Output("map-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows")
    )
    def update_map(view_data, selected_rows):
        default_center = [39.8283, -98.5795]

        if not view_data or not selected_rows:
            return dl.Map(
                center=default_center,
                zoom=4,
                style={"width": "100%", "height": "500px"},
                children=[dl.TileLayer()]
            )

        dff = pd.DataFrame(view_data)
        row = selected_rows[0]

        if row >= len(dff):
            return dl.Map(
                center=default_center,
                zoom=4,
                style={"width": "100%", "height": "500px"},
                children=[dl.TileLayer()]
            )

        return dl.Map(
            center=[dff.iloc[row]["latitude"], dff.iloc[row]["longitude"]],
            zoom=10,
            style={"width": "100%", "height": "500px"},
            children=[
                dl.TileLayer(),
                dl.Marker(
                    position=[dff.iloc[row]["latitude"], dff.iloc[row]["longitude"]],
                    children=[
                        dl.Tooltip(dff.iloc[row]["breed"]),
                        dl.Popup(dff.iloc[row]["name"])
                    ]
                )
            ]
        )
